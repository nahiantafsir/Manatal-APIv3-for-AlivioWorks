<?php
/**
 * Plugin Name: Manatal Careers (API v3) for AlivioWorks
 * Description: Renders Manatal jobs + dynamic application forms via Career Page API v3 (no token). Shortcodes: [manatal_jobs], [manatal_apply], [manatal_jobs_debug], [manatal_apply_debug].
 * Version: 1.0.4.7
 * Author: Tafsirul Islam
 * Text Domain: manatal-careers-alivio
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('Manatal_Careers_Plugin_Alivio')):
class Manatal_Careers_Plugin_Alivio {
  const BASE = 'https://api.manatal.com/open/v3/career-page';
  const DEFAULT_SLUG = 'alivioworks';
  const LISTING_PAGE = '/find-a-job/';

  public function __construct() {
    add_shortcode('manatal_jobs',        [$this, 'shortcode_jobs']);
    add_shortcode('manatal_apply',       [$this, 'shortcode_apply']);
    add_shortcode('manatal_jobs_debug',  [$this, 'shortcode_jobs_debug']);
    add_shortcode('manatal_apply_debug', [$this, 'shortcode_apply_debug']);

    add_action('wp_enqueue_scripts', function () {
      wp_enqueue_style('manatal-careers', plugin_dir_url(__FILE__) . 'styles.css', [], '1.0.4.7');
    });

    add_action('init', function () {
      if (!empty($_POST['manatal_apply_nonce']) && wp_verify_nonce($_POST['manatal_apply_nonce'], 'manatal_apply')) {
        $this->handle_application_submit();
      }
    });
  }

  private function fetch_json($url, $cache_key, $ttl = 300, &$debug = null) {
    $force = isset($_GET['mtl_refresh']) && current_user_can('manage_options');
    if (!$force) {
      $cached = get_transient($cache_key);
      if ($cached) { if (is_array($debug)) $debug['cache'] = 'hit'; return $cached; }
    }
    $res = wp_remote_get($url, ['timeout' => 20]);
    if (is_wp_error($res)) { if (is_array($debug)) $debug['error'] = $res->get_error_message(); return null; }
    $code = wp_remote_retrieve_response_code($res);
    $body = wp_remote_retrieve_body($res);
    if ($code !== 200) { if (is_array($debug)) { $debug['http_code'] = $code; $debug['body'] = $body; } return null; }
    $data = json_decode($body, true);
    if ($data === null && is_array($debug)) $debug['json_error'] = 'Invalid JSON';
    set_transient($cache_key, $data, $ttl);
    if (is_array($debug)) $debug['cache'] = 'miss';
    return $data;
  }

  /** Jobs list */
  public function shortcode_jobs($atts) {
    $atts = shortcode_atts(['slug' => '', 'per_page' => '50'], $atts);
    if (!$atts['slug']) $atts['slug'] = self::DEFAULT_SLUG;

    $url  = sprintf('%s/%s/jobs/?page=1&page_size=%d', self::BASE, urlencode($atts['slug']), (int)$atts['per_page']);
    $data = $this->fetch_json($url, 'manatal_jobs_' . md5($url));
    if (!$data) return '<p>Unable to load jobs right now.</p>';
    if (empty($data['results'])) return '<p>No jobs found.</p>';

    ob_start();
    echo '<div class="mtl-jobs">';
    foreach ($data['results'] as $job) {
      $title = !empty($job['position_name']) ? $job['position_name'] : (!empty($job['title']) ? $job['title'] : (!empty($job['name']) ? $job['name'] : 'View job'));
      $locs  = !empty($job['location_display']) ? $job['location_display'] : implode(', ', array_filter([$job['city'] ?? '', $job['state'] ?? '', $job['country'] ?? '']));
      $dept  = !empty($job['department']['name']) ? $job['department']['name'] : ($job['department_name'] ?? '');
      $id    = $job['id'] ?? ($job['job_id'] ?? '');
      if (!$id) continue;
      $link = home_url('/apply/?manatal_job=' . urlencode($id) . '&manatal_slug=' . urlencode($atts['slug']));
      echo '<article class="mtl-job">';
      echo "<h3><a class='mtl-job-link' href='".esc_url($link)."'>".esc_html($title)."</a></h3>";
      $meta = trim(($dept ?: '') . (($dept && $locs) ? ' — ' : '') . ($locs ?: ''));
      if ($meta) echo '<p class="mtl-meta">'.esc_html($meta).'</p>';
      echo '</article>';
    }
    echo '</div>';
    return ob_get_clean();
  }

  /** Jobs debug */
  public function shortcode_jobs_debug($atts) {
    $atts = shortcode_atts(['slug' => ''], $atts);
    if (!$atts['slug']) $atts['slug'] = self::DEFAULT_SLUG;

    $debug = ['slug' => $atts['slug']];
    $url   = sprintf('%s/%s/jobs/?page=1&page_size=50', self::BASE, urlencode($atts['slug']));
    $data  = $this->fetch_json($url, 'manatal_jobs_' . md5($url) . '_debug', 0, $debug);

    ob_start();
    echo '<pre class="mtl-debug" style="white-space:pre-wrap;background:#f8fafc;border:1px solid #e5e7eb;padding:12px;border-radius:8px;">';
    echo esc_html(print_r([
      'request_url' => $url,
      'http_code'   => $debug['http_code'] ?? 200,
      'cache'       => $debug['cache'] ?? 'n/a',
      'error'       => $debug['error'] ?? null,
      'json_error'  => $debug['json_error'] ?? null,
      'count'       => isset($data['results']) ? count($data['results']) : 0,
      'sample'      => isset($data['results'][0]) ? array_intersect_key($data['results'][0], array_flip(['id','position_name','title'])) : null,
    ], true));
    echo '</pre>';
    return ob_get_clean();
  }

  /** Apply debug */
  public function shortcode_apply_debug($atts) {
    $atts = shortcode_atts(['slug' => '', 'id' => ''], $atts);
    $job_id = $atts['id'] ?: sanitize_text_field($_GET['manatal_job'] ?? '');
    $slug   = $atts['slug'] ?: sanitize_text_field($_GET['manatal_slug'] ?? self::DEFAULT_SLUG);
    if (!$job_id) return '<p>Provide id="" or ?manatal_job= in URL.</p>';

    $debug = [];
    $url   = sprintf('%s/%s/jobs/%s/application-form/', self::BASE, urlencode($slug), urlencode($job_id));
    $data  = $this->fetch_json($url, 'manatal_form_' . md5($url) . '_debug', 0, $debug);

    $fields = [];
    if (is_array($data)) {
      if (isset($data['fields']) && is_array($data['fields'])) $fields = $data['fields'];
      else $fields = $data;
    }

    $first = isset($fields[0]) ? array_intersect_key($fields[0], array_flip(['id','slug','label','type','display_type','is_required','field_category'])) : null;

    ob_start();
    echo '<pre class="mtl-debug" style="white-space:pre-wrap;background:#f8fafc;border:1px solid #e5e7eb;padding:12px;border-radius:8px;">';
    echo esc_html(print_r([
      'request_url' => $url,
      'http_code'   => $debug['http_code'] ?? 200,
      'fields_count'=> count($fields),
      'first_field' => $first,
      'note'        => 'Submission uses numeric field IDs with JSON; resume is sent as base64 per docs.',
    ], true));
    echo '</pre>';
    return ob_get_clean();
  }

  private function is_file_field($f) {
    $disp = strtolower($f['display_type'] ?? '');
    $type = strtolower($f['type'] ?? '');
    $slug = strtolower($f['slug'] ?? '');
    $label= strtolower($f['label'] ?? '');
    $cat  = strtolower($f['field_category'] ?? '');
    if (in_array($disp, ['file','file_upload','upload','document'])) return true;
    if (in_array($type, ['file','document'])) return true;
    if (preg_match('/\b(cv|résumé|resume)\b/i', $slug . ' ' . $label . ' ' . $cat)) return true;
    if (in_array($slug, ['resume','cv','cv_file','resume_file','document','attachment'])) return true;
    if ($cat === 'resume' || $cat === 'attachments') return true;
    return false;
  }

  /** Apply page */
  public function shortcode_apply($atts) {
    $atts = shortcode_atts(['slug' => '', 'id' => ''], $atts);

    // Success/failure notice
    if (isset($_GET['applied'])) {
      $ok = ($_GET['applied'] === '1');
      $home = esc_url(home_url('/'));
      $msg  = $ok ? 'Your application was submitted successfully.' : 'We could not submit your application. Please try again.';
      $cls  = $ok ? 'mtl-notice success' : 'mtl-notice error';
      $auto = '<script>setTimeout(function(){window.location.href="'. $home .'";}, 10000);</script>';
      // Optional verbose error for admins if present
      $err = isset($_GET['err']) && current_user_can('manage_options') ? '<pre class="mtl-debug">'. esc_html(base64_decode($_GET['err'])) .'</pre>' : '';
      return '<div class="'. esc_attr($cls) .'"><p>'. esc_html($msg) .' Redirecting to the homepage in 10 seconds… <a href="'. $home .'">Go now</a>.</p></div>'. $err . $auto;
    }

    $job_id = $atts['id'];
    if (!$job_id) $job_id = sanitize_text_field($_GET['manatal_job'] ?? '');

    if (!$atts['slug']) $atts['slug'] = sanitize_text_field($_GET['manatal_slug'] ?? '');
    if (!$atts['slug']) $atts['slug'] = self::DEFAULT_SLUG;

    if (!$job_id) {
      $list_url = esc_url( home_url(self::LISTING_PAGE) );
      return '<p>Missing job information. Please choose a role from the <a href="'.$list_url.'">Find a Job</a> page.</p>';
    }

    // Job header
    $job_url = sprintf('%s/%s/jobs/%s/', self::BASE, urlencode($atts['slug']), urlencode($job_id));
    $job = $this->fetch_json($job_url, 'manatal_job_' . md5($job_url), 120);
    $title = $locs = $contract = $desc = '';
    if ($job) {
      $title = esc_html($job['position_name'] ?? ($job['title'] ?? ''));
      $locs  = esc_html($job['location_display'] ?? '');
      $contract = esc_html($job['contract_details'] ?? '');
      $desc  = !empty($job['description']) ? wp_kses_post($job['description']) : '';
    }

    // Form schema
    $debug = [];
    $url = sprintf('%s/%s/jobs/%s/application-form/', self::BASE, urlencode($atts['slug']), urlencode($job_id));
    $data = $this->fetch_json($url, 'manatal_form_' . md5($url), 120, $debug);

    $fields = [];
    if (is_array($data)) {
      if (isset($data['fields']) && is_array($data['fields'])) $fields = $data['fields'];
      else $fields = $data;
    }
    if (empty($fields)) {
      return '<p>Application form unavailable. Add <code>[manatal_apply_debug id="'.esc_html($job_id).'" slug="'.esc_html($atts['slug']).'"]</code> to inspect.</p>';
    }

    ob_start();
    echo '<section class="mtl-job-header">';
    if ($title) echo '<h2 class="mtl-job-title">'. $title .'</h2>';
    $bits = array_filter([$contract, $locs]);
    if ($bits) echo '<p class="mtl-job-sub">'. esc_html(implode(' • ', $bits)) .'</p>';
    if ($desc) echo '<div class="mtl-job-desc">'. $desc .'</div>';
    echo '</section>';

    echo '<form class="mtl-apply" method="post" enctype="multipart/form-data">';
    wp_nonce_field('manatal_apply', 'manatal_apply_nonce');
    echo '<input type="hidden" name="manatal_job_id" value="'.esc_attr($job_id).'">';
    echo '<input type="hidden" name="manatal_slug" value="'.esc_attr($atts['slug']).'">';

    foreach ($fields as $field) {
      $fid_num = isset($field['id']) ? intval($field['id']) : 0;
      $html_id = esc_attr(($field['slug'] ?? '') ?: ($fid_num ? 'field_'.$fid_num : ''));
      if (!$fid_num) continue; // require numeric id to submit correctly
      $label = esc_html($field['label'] ?? ucfirst(str_replace('_',' ',$html_id)));
      $req   = !empty($field['required']) || !empty($field['is_required']);
      $type  = strtolower($field['type'] ?? 'char');
      $display= strtolower($field['display_type'] ?? '');
      $choices = $field['choices'] ?? ($field['options'] ?? []);
      $accept  = $field['accept'] ?? ($field['file_extensions'] ?? ($field['allowed_extensions'] ?? ''));
      $maxsize = $field['max_size_mb'] ?? ($field['max_size'] ?? '');
      $multiple = !empty($field['multiple']) || in_array($display, ['checkboxes','multiple_select']) || ($type === 'array' || $type === 'list');

      echo '<div class="mtl-field">';
      echo "<label for='f_$html_id'>$label".($req?' *':'')."</label>";

      if (!empty($choices) && $multiple) {
        foreach ($choices as $idx => $c) {
          $val = is_array($c) ? ($c['value'] ?? ($c['id'] ?? ($c['slug'] ?? $c))) : $c;
          $txt = is_array($c) ? ($c['label'] ?? ($c['name'] ?? $val)) : $c;
          $id  = "f_{$html_id}_$idx";
          echo "<label class='mtl-opt'><input type='checkbox' id='$id' name='f_{$fid_num}[]' value='".esc_attr($val)."' ".($req?'required':'')."> ".esc_html($txt)."</label>";
        }
      } elseif (!empty($choices) && !$multiple) {
        echo "<select id='f_$html_id' name='f_{$fid_num}' ".($req?'required':'').">";
        echo "<option value=''>Select…</option>";
        foreach ($choices as $c) {
          $val = is_array($c) ? ($c['value'] ?? ($c['id'] ?? ($c['slug'] ?? $c))) : $c;
          $txt = is_array($c) ? ($c['label'] ?? ($c['name'] ?? $val)) : $c;
          echo "<option value='".esc_attr($val)."'>".esc_html($txt)."</option>";
        }
        echo "</select>";
      } elseif ($this->is_file_field($field)) {
        // Resume/attachment (captured under file_{id} to base64 on submit)
        $accept_attr = '';
        if (is_array($accept) && !empty($accept)) {
          $exts = array();
          foreach ($accept as $a) {
            $a = trim($a);
            if (!$a) continue;
            if ($a[0] !== '.') $a = '.' . ltrim($a, '*.');
            $exts[] = $a;
          }
          if (!empty($exts)) $accept_attr = ' accept="'. esc_attr(implode(',', $exts)) .'"';
        } elseif (is_string($accept) && $accept !== '') {
          $parts = preg_split('/[,|]/', $accept);
          $exts = array();
          foreach ($parts as $p) {
            $p = trim($p);
            if (!$p) continue;
            if ($p[0] !== '.') $p = '.' . ltrim($p, '*.');
            $exts[] = $p;
          }
          if (!empty($exts)) $accept_attr = ' accept="'. esc_attr(implode(',', $exts)) .'"';
        } else {
          $accept_attr = ' accept=".pdf,.doc,.docx,.rtf,.odt"';
        }
        echo "<input type='file' id='f_$html_id' name='file_{$fid_num}' $accept_attr ".($req?'required':'')." />";
        if ($maxsize) echo '<small class="mtl-help">Max file size: '.esc_html(is_numeric($maxsize)?($maxsize.' MB'):$maxsize).'</small>';
      } elseif ($display === 'textarea' || $type === 'text_long' || $type === 'longtext') {
        echo "<textarea id='f_$html_id' name='f_{$fid_num}' ".($req?'required':'')."></textarea>";
      } elseif ($display === 'checkbox' || $type === 'boolean') {
        echo "<input type='checkbox' id='f_$html_id' name='f_{$fid_num}' value='true' ".($req?'required':'')." />";
      } elseif (in_array($display, ['email','url','number','date']) || in_array($type, ['email','url','number','date','integer','datetime'])) {
        $input_type = in_array($display, ['email','url','number','date']) ? $display : ($type==='integer' ? 'number' : ($type==='datetime' ? 'date' : $type));
        echo "<input type='".esc_attr($input_type)."' id='f_$html_id' name='f_{$fid_num}' ".($req?'required':'')." />";
      } else {
        echo "<input type='text' id='f_$html_id' name='f_{$fid_num}' ".($req?'required':'')." />";
      }

      if (!empty($field['help_text'])) {
        echo '<small class="mtl-help">'. esc_html($field['help_text']) .'</small>';
      }

      echo '</div>';
    }

    echo '<button type="submit" class="mtl-submit">Submit Application</button>';
    echo '</form>';
    return ob_get_clean();
  }

  /** Submit application (JSON + base64 file for resume) */
  private function handle_application_submit() {
    $job_id = sanitize_text_field($_POST['manatal_job_id'] ?? '');
    $slug   = sanitize_text_field($_POST['manatal_slug'] ?? '');
    if (!$slug) $slug = self::DEFAULT_SLUG;
    if (!$job_id || !$slug) return;

    $app = array();

    // Text / selects using numeric ids: f_{id}
    foreach ($_POST as $k => $v) {
      if (strpos($k, 'f_') !== 0) continue;
      $fid = substr($k, 2);
      if (!ctype_digit((string)$fid)) continue;
      if (is_array($v)) {
        $flat = array();
        foreach ($v as $vv) { $flat[] = sanitize_text_field($vv); }
        $app[$fid] = implode(',', $flat);
      } else {
        if ($v === 'on') $v = 'true';
        $app[$fid] = sanitize_text_field($v);
      }
    }

    // Files under file_{id} -> convert to base64 string
    foreach ($_FILES as $k => $file) {
      if (strpos($k, 'file_') !== 0 || empty($file['tmp_name'])) continue;
      $fid = substr($k, 5);
      if (!ctype_digit((string)$fid)) continue;
      $content = file_get_contents($file['tmp_name']);
      if ($content !== false) {
        $app[$fid] = base64_encode($content);
      }
    }

    $payload = wp_json_encode(array('application_data' => $app));
    $url = sprintf('%s/%s/jobs/%s/application-form/', self::BASE, rawurlencode($slug), rawurlencode($job_id));
    $res = wp_remote_post($url, [
      'headers' => ['Content-Type' => 'application/json'],
      'body'    => $payload,
      'timeout' => 60,
    ]);

    $ok = !is_wp_error($res) && wp_remote_retrieve_response_code($res) < 300;
    $err = '';
    if (!$ok) {
      $err = is_wp_error($res) ? $res->get_error_message() : wp_remote_retrieve_body($res);
    }
    $redir = add_query_arg([
      'applied' => $ok ? '1' : '0',
      'err'     => $err ? base64_encode($err) : null
    ], home_url('/apply/'));
    wp_safe_redirect($redir);
    exit;
  }
}
new Manatal_Careers_Plugin_Alivio();
endif;
