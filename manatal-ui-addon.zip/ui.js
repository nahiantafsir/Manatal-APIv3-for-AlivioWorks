
(function(){
  function toTitleCase(s){
    if(!s) return '';
    s = String(s).replace(/_/g,' ').toLowerCase().replace(/\s+/g,' ').trim();
    return s.replace(/\b\w/g, function(m){ return m.toUpperCase(); });
  }
  function collectItems(scope){
    var out = [];
    var seen = {};
    scope.querySelectorAll('.mtl-item').forEach(function(el){
      var title = (el.getAttribute('data-title')||'').trim();
      var location = (el.getAttribute('data-location')||'').trim();
      var contract = toTitleCase(el.getAttribute('data-contract')||'');
      var date = (el.getAttribute('data-date')||'').trim();
      var url = (el.getAttribute('data-url')||'').trim();
      var id = url || title+'|'+location;
      if(seen[id]) return;
      seen[id] = true;
      out.push({title:title, location:location, contract:contract, date:date, url:url});
    });
    return out;
  }
  function makeCard(item){
    var card = document.createElement('div');
    card.className = 'mtl-card';
    card.innerHTML = ''
      + '<header class="mtl-card__header"><h3 class="mtl-card__title"><a href="'+item.url+'">'+item.title+'</a></h3></header>'
      + '<ul class="mtl-card__meta">'
      +   (item.contract ? '<li class="mtl-meta__row"><span class="mtl-icon">💼</span>'+item.contract+'</li>' : '')
      +   (item.location ? '<li class="mtl-meta__row"><span class="mtl-icon">📍</span>'+item.location+'</li>' : '')
      +   (item.date ? '<li class="mtl-meta__row"><span class="mtl-icon">📅</span>'+item.date+'</li>' : '')
      + '</ul>'
      + '<p><a class="mtl-btn" href="'+item.url+'">View &amp; Apply</a></p>';
    return card;
  }
  function makeListRow(item){
    var wrap = document.createElement('div');
    wrap.className = 'mtl-item-render';
    var row = document.createElement('div');
    row.className = 'mtl-list__row';
    var titleA = document.createElement('a');
    titleA.className = 'mtl-list__title';
    titleA.href = item.url;
    titleA.textContent = item.title;
    var meta = document.createElement('span');
    meta.className = 'mtl-list__meta';
    if(item.contract){
      var s = document.createElement('span'); s.className='mtl-meta__row';
      s.innerHTML = '<span class="mtl-icon">💼</span>'+item.contract; meta.appendChild(s);
    }
    if(item.location){
      var s2 = document.createElement('span'); s2.className='mtl-meta__row';
      s2.innerHTML = '<span class="mtl-icon">📍</span>'+item.location; meta.appendChild(s2);
    }
    if(item.date){
      var s3 = document.createElement('span'); s3.className='mtl-meta__row';
      s3.innerHTML = '<span class="mtl-icon">📅</span>'+item.date; meta.appendChild(s3);
    }
    var cta = document.createElement('a');
    cta.className = 'mtl-btn mtl-list__cta';
    cta.href = item.url; cta.textContent = 'View & Apply';

    row.appendChild(titleA);
    row.appendChild(meta);
    row.appendChild(cta);
    wrap.appendChild(row);
    return wrap;
  }
  function render(scope, items, view, cols){
    var results = scope;
    results.innerHTML = ''; // clear
    results.setAttribute('data-view', view);
    results.className = results.className.replace(/\bmtl-cols-\d+\b/g, '').trim();
    results.classList.add('mtl-cols-' + cols);
    items.forEach(function(it){
      results.appendChild(view === 'grid' ? makeCard(it) : makeListRow(it));
    });
  }
  function attach(root){
    var toolbar = root.previousElementSibling && root.previousElementSibling.classList.contains('mtl-toolbar')
      ? root.previousElementSibling : document.querySelector('.mtl-toolbar[data-scope="#'+root.id+'"]');
    var input = toolbar ? toolbar.querySelector('.mtl-search-input') : null;
    var searchBtn = toolbar ? toolbar.querySelector('.mtl-search-btn') : null;
    var countEl = toolbar ? toolbar.querySelector('[data-mtl-count]') : null;
    var viewBtns = toolbar ? toolbar.querySelectorAll('.mtl-view-btn') : [];
    var all = collectItems(root.parentNode);
    var match = (root.getAttribute('class')||'').match(/mtl-cols-(\d+)/);
    var cols = match ? match[1] : '3';
    var view = root.getAttribute('data-view') || 'grid';

    function applyFilter(){
      var q = (input && input.value || '').toLowerCase().trim();
      var filtered = !q ? all : all.filter(function(it){
        return (it.title+' '+it.location+' '+it.contract).toLowerCase().indexOf(q) !== -1;
      });
      if(countEl){ countEl.textContent = filtered.length + ' job(s) found'; }
      render(root, filtered, view, cols);
    }

    if (input){ input.addEventListener('input', applyFilter); }
    if (searchBtn){ searchBtn.addEventListener('click', applyFilter); }
    viewBtns.forEach(function(btn){
      btn.addEventListener('click', function(){
        viewBtns.forEach(function(b){ b.setAttribute('aria-pressed','false'); });
        btn.setAttribute('aria-pressed','true');
        view = btn.getAttribute('data-view') || 'grid';
        applyFilter();
      });
    });

    var urlQ = (new URLSearchParams(window.location.search)).get('q') || '';
    if (input && urlQ && !input.value) { input.value = urlQ; }
    applyFilter();
  }

  function fixApplyPage(){
    var TOKENS = ['full_time','part_time','temporary','contract','internship','permanent','casual','seasonal','contract_to_hire'];
    var re = new RegExp('\\b(' + TOKENS.join('|') + ')\\b','g');
    document.querySelectorAll('body *').forEach(function(el){
      if(el.children && el.children.length) return;
      var txt = el.textContent;
      if(!txt || txt.length > 80) return;
      var t = txt.replace(re, function(m){ return toTitleCase(m); });
      t = t.replace(/^\s*([a-z_]+)(\s*•)/, function(_m, p1, p2){ return toTitleCase(p1)+p2; });
      if(t !== txt){ el.textContent = t; }
    });
  }

  function init(){
    document.querySelectorAll('.mtl-results').forEach(function(res){ attach(res); });
    fixApplyPage();
  }
  if(document.readyState === 'loading'){ document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();


// === Manatal Careers UI Addon 1.2.3 UI tweaks ===
(function(){
  function ready(fn){ if(document.readyState!='loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn);}}
  ready(function(){
    // Replace leading pin emoji from address text
    var addrSel = ['.job-location','.manatal-job-location','.manatal-address'];
    addrSel.forEach(function(sel){
      document.querySelectorAll(sel).forEach(function(el){
        var txt = el.textContent || '';
        // Remove common pin emojis if present
        var cleaned = txt.replace(/^\s*(📍|📌|🧭)\s*/u, '');
        if(cleaned !== txt){
          el.textContent = cleaned;
        }
        el.classList.add('has-svgin-pin');
      });
    });

    // Add visually-hidden text for toggle buttons if they only contain icons
    var gridBtns = document.querySelectorAll('.manatal-toggle .btn-grid, .manatal-view-toggle .btn-grid, .manatal-toggle [data-view="grid"], .manatal-view-toggle [data-view="grid"]');
    gridBtns.forEach(function(btn){
      if(!btn.querySelector('.visually-hidden')){
        var span = document.createElement('span');
        span.className = 'visually-hidden';
        span.textContent = 'Grid view';
        btn.appendChild(span);
      }
    });
    var listBtns = document.querySelectorAll('.manatal-toggle .btn-list, .manatal-view-toggle .btn-list, .manatal-toggle [data-view="list"], .manatal-view-toggle [data-view="list"]');
    listBtns.forEach(function(btn){
      if(!btn.querySelector('.visually-hidden')){
        var span = document.createElement('span');
        span.className = 'visually-hidden';
        span.textContent = 'List view';
        btn.appendChild(span);
      }
    });

    // Force grid view on small screens if list is active
    function enforceMobileGrid(){
      if(window.innerWidth <= 768){
        var list = document.querySelector('.manatal-list');
        var grid = document.querySelector('.manatal-grid');
        if(list && getComputedStyle(list).display !== 'none'){
          list.style.display = 'none';
          if(grid){ grid.style.display = 'grid'; }
        }
      }
    }
    window.addEventListener('resize', enforceMobileGrid);
    enforceMobileGrid();
  });
})();


// Ensure only icons are visible on toggle buttons (remove visible text, keep aria + hidden label)
function _removeTextNodes(el){
  var remove = [];
  el.childNodes.forEach(function(n){
    if(n.nodeType === Node.TEXT_NODE && n.textContent.trim().length){
      remove.append(n);
    }
  });
  remove.forEach(function(n){ el.removeChild(n); });
}

// Upgrade toggle buttons: clear text, set aria-labels
(function(){
  function cleanupBtn(btn, label){
    // Remove direct text nodes so words aren't visible
    var toRemove = [];
    btn.childNodes.forEach(function(n){
      if(n.nodeType === 3 && n.textContent.trim().length){ toRemove.push(n); }
    });
    toRemove.forEach(function(n){ btn.removeChild(n); });
    // Add/ensure visually hidden label
    var vh = btn.querySelector('.visually-hidden');
    if(!vh){
      vh = document.createElement('span');
      vh.className = 'visually-hidden';
      vh.textContent = label;
      btn.appendChild(vh);
    }
    btn.setAttribute('aria-label', label);
  }

  var _grid = document.querySelectorAll('.manatal-toggle .btn-grid, .manatal-view-toggle .btn-grid, .manatal-toggle [data-view="grid"], .manatal-view-toggle [data-view="grid"]');
  _grid.forEach(function(b){ cleanupBtn(b, 'Grid view'); });

  var _list = document.querySelectorAll('.manatal-toggle .btn-list, .manatal-view-toggle .btn-list, .manatal-toggle [data-view="list"], .manatal-view-toggle [data-view="list"]');
  _list.forEach(function(b){ cleanupBtn(b, 'List view'); });
})();


// === MTL v1.2.4 UI helpers ===
(function(){
  function ready(fn){ if(document.readyState!='loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn);}}
  function enforceMobileGrid(){
    var isMobile = window.innerWidth <= 768;
    if(!isMobile) return;
    document.querySelectorAll('.mtl-results').forEach(function(scope){
      if(scope.getAttribute('data-view') === 'list'){
        scope.setAttribute('data-view','grid');
        // sync toolbar buttons
        var id = scope.getAttribute('id');
        if(id){
          var tb = document.querySelector('.mtl-toolbar[data-scope="#'+id+'"]');
          if(tb){
            tb.querySelectorAll('.mtl-view-btn').forEach(function(b){
              b.setAttribute('aria-pressed', b.getAttribute('data-view')==='grid' ? 'true':'false');
            });
          }
        }
      }
    });
  }
  ready(function(){
    enforceMobileGrid();
    window.addEventListener('resize', enforceMobileGrid);
  });
})();

// v1.2.5: Clean leading emoji from .mtl-job-loc if any
(function(){
  function ready(fn){ if(document.readyState!='loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn);}}
  ready(function(){
    document.querySelectorAll('.mtl-job-loc').forEach(function(el){
      var t = el.textContent || '';
      var cleaned = t.replace(/^\s*(📍|📌|🧭)\s*/u,'');
      if(cleaned!==t){ el.textContent = cleaned; }
    });
  });
})();

// === MTL v1.2.6 DOM hardening ===
(function(){
  function cleanIcons(root){
    // Replace grid meta emoji with empty span + data-kind
    root.querySelectorAll('.mtl-card__meta .mtl-meta__row .mtl-icon').forEach(function(el){
      var t = (el.textContent||'').trim();
      if (t) { el.textContent = ''; }
      // Mark kind based on next sibling text
      var rowText = el.parentElement ? el.parentElement.textContent.toLowerCase() : '';
      if (rowText.indexOf('full')>-1 || rowText.indexOf('part')>-1 || rowText.indexOf('contract')>-1) el.setAttribute('data-kind','contract');
      if (rowText.indexOf('jan')>-1 || rowText.indexOf('feb')>-1 || /\d{4}/.test(rowText)) el.setAttribute('data-kind','date');
      if (!el.getAttribute('data-kind')) el.setAttribute('data-kind','location');
    });
    // Insert dedicated svg pin at start of list location; strip any leading emoji
    root.querySelectorAll('.mtl-job-loc').forEach(function(el){
      var t = el.textContent || '';
      var cleaned = t.replace(/^\s*(📍|📌|🧭)\s*/u,'');
      if (cleaned !== t) { el.textContent = cleaned; }
      if (!el.querySelector('.mtl-pin')){
        var pin = document.createElement('span');
        pin.className = 'mtl-pin'; pin.setAttribute('aria-hidden','true');
        el.insertBefore(pin, el.firstChild);
      }
    });
  }
  function ready(fn){ if(document.readyState!='loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn);}}
  ready(function(){
    var scopes = document.querySelectorAll('.mtl-results');
    scopes.forEach(function(scope){
      cleanIcons(scope);
      var mo = new MutationObserver(function(){ cleanIcons(scope); });
      mo.observe(scope, {childList:true, subtree:true});
    });
  });
})();
