(function(){
  function escapeHtml(s){return (s||'').replace(/[&<>"]/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]);});}
  function formatDate(d){var dt=new Date(d); return isNaN(dt)? d : dt.toLocaleDateString(undefined,{year:'numeric',month:'short',day:'2-digit'});}
  function truncate(t,n){ if(!t) return ''; return (t.length>n)? (t.slice(0,Math.max(1,n-1))+'…') : t; }
  function renderItems(scope){
    var view = scope.getAttribute('data-view') || 'grid';
    var maxTitle = parseInt(scope.getAttribute('data-max-title')||'60',10);
    var btnLabel = scope.getAttribute('data-button-label') || 'View & Apply';
    var titleTag = scope.getAttribute('data-title-tag') || 'h3';
    var titleStyle = scope.getAttribute('data-title-style') || '';
    scope.querySelectorAll('.mtl-item-render').forEach(function(n){ n.remove(); });
    Array.prototype.slice.call(scope.querySelectorAll('.mtl-item')).forEach(function(it){
      var title = it.getAttribute('data-title')||''; if (!title) return;
      var location = it.getAttribute('data-location')||'';
      var contract = it.getAttribute('data-contract')||'';
      var dateRaw = it.getAttribute('data-date')||'';
      var url = it.getAttribute('data-url')||'#';
      var el = document.createElement('div');
      el.className = (view==='grid') ? 'mtl-card mtl-item-render' : 'mtl-item-render';
      if (view==='grid'){
        el.innerHTML = '<header class="mtl-card__header"><'+titleTag+' class="mtl-card__title" style="'+titleStyle+'"><a href="'+url+'">'+escapeHtml(truncate(title,maxTitle))+'</a></'+titleTag+'></header>' +
          '<ul class="mtl-card__meta">' +
            (location? '<li class="mtl-meta__row"><span class="mtl-icon" aria-hidden="true"></span>'+escapeHtml(location)+'</li>':'') +
            (contract? '<li class="mtl-meta__row"><span class="mtl-icon">💼</span>'+escapeHtml(contract)+'</li>':'') +
            (dateRaw? '<li class="mtl-meta__row"><span class="mtl-icon">📅</span>'+escapeHtml(formatDate(dateRaw))+'</li>':'') +
          '</ul>' +
          '<p><a class="mtl-btn" href="'+url+'">'+escapeHtml(btnLabel)+'</a></p>';
      } else {
        el.innerHTML = '<a class="mtl-job-title" href="'+url+'">'+escapeHtml(truncate(title,maxTitle))+'</a>' +
          (location? '<span class="mtl-job-loc">'+escapeHtml(location)+'</span>':'') +
          (contract? '<span class="mtl-job-type">'+escapeHtml(contract)+'</span>':'') +
          (dateRaw? '<time class="mtl-job-date">'+escapeHtml(formatDate(dateRaw))+'</time>':'') +
          ' <a class="mtl-btn mtl-inline-btn" href="'+url+'">'+escapeHtml(btnLabel)+'</a>';
      }
      el.setAttribute('data-text', (title+' '+location+' '+contract).toLowerCase());
      scope.appendChild(el);
    });
  }
  function setupToolbar(toolbar){
    var scopeSel = toolbar.getAttribute('data-scope');
    var scope = scopeSel ? document.querySelector(scopeSel) : null;
    if (!scope) return;
    var input = toolbar.querySelector('.mtl-search-input');
    var viewBtns = toolbar.querySelectorAll('.mtl-view-btn');
    var countEl = toolbar.querySelector('[data-mtl-count]');
    function updateCount(){ var visible = scope.querySelectorAll('.mtl-item-render').length; countEl.textContent = visible + ' job(s) found'; }
    function applyFilter(){
      renderItems(scope);
      var q = (input && input.value || '').trim().toLowerCase();
      if (!q){ updateCount(); return; }
      Array.prototype.slice.call(scope.querySelectorAll('.mtl-item-render')).forEach(function(c){
        var hay = (c.getAttribute('data-text') || '').toLowerCase();
        if (hay.indexOf(q) === -1){ c.remove(); }
      });
      updateCount();
    }
    if (input) input.addEventListener('input', applyFilter);
    viewBtns.forEach(function(btn){
      btn.addEventListener('click', function(){
        var view = btn.getAttribute('data-view');
        scope.setAttribute('data-view', view);
        viewBtns.forEach(function(b){ b.setAttribute('aria-pressed', b===btn ? 'true':'false'); });
        applyFilter();
      });
    });
    applyFilter();
  }
  function init(){ document.querySelectorAll('.mtl-toolbar[data-scope]').forEach(setupToolbar); }
  if (document.readyState === 'loading'){ document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();