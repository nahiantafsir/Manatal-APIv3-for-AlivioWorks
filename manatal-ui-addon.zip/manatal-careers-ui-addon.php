<?php
/**
 * Plugin Name: Manatal Careers UI Add-on (Alivio)
 * Description: UI layer for Manatal Careers plugin. Replaces [manatal_jobs], adds [manatal_featured_job] and [manatal_jobs_search] to match your layout—without touching core GET/POST logic.
 * Version: 1.2.6.4
 * Author: Tafsirul Islam
 * Text Domain: manatal-careers-ui-addon
 */

if (!defined('ABSPATH')) exit;

class Manatal_Careers_UI_Addon {
  const DEP_CLASS = 'Manatal_Careers_Plugin_Alivio';

  public function __construct() {
    add_action('plugins_loaded', [$this, 'maybe_boot']);
  }

  public function maybe_boot() {
    if (!class_exists(self::DEP_CLASS)) {
      add_action('admin_notices', function(){
        echo '<div class="notice notice-error"><p><strong>Manatal Careers UI Add-on</strong> requires the core <em>Manatal Careers (API v3) for AlivioWorks</em> plugin to be active.</p></div>';
      });
      return;
    }
    add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);

    remove_shortcode('manatal_jobs');
    add_shortcode('manatal_jobs', [$this, 'shortcode_jobs']);

    add_shortcode('manatal_featured_job', [$this, 'shortcode_featured_job']);
    add_shortcode('manatal_jobs_search', [$this, 'shortcode_jobs_search']);
  }

  public function enqueue_assets() {
    $h = 'manatal-careers-ui-addon';
    $ver = '1.1.0';
    wp_register_style($h, plugins_url('style.css', __FILE__), [], $ver);
    wp_enqueue_style($h);
    wp_register_style($h . '-addon', plugins_url('addon.css', __FILE__), [$h], $ver);
    wp_enqueue_style($h . '-addon');
    wp_register_script($h, plugins_url('script.js', __FILE__), ['jquery'], $ver, true);
    wp_enqueue_script($h);
    wp_register_script($h . '-ui', plugins_url('ui.js', __FILE__), [$h], $ver, true);
    wp_enqueue_script($h . '-ui');
  }

  private function pretty_contract($s){
    if (!is_string($s) || $s==='') return '';
    $s = str_replace('_',' ', strtolower($s));
    $s = preg_replace('/\s+/', ' ', trim($s));
    return ucwords($s);
  }

  private function extract_contract($job){
    $keys = [
      ['contract_type','name'], ['employment_type','name'], ['job_type','name'],
      ['contract_type'], ['employment_type'], ['job_type'], ['type'],
      ['contract'], ['work_type'], ['work_schedule'], ['employmentType'], ['jobType']
    ];
    foreach ($keys as $path){
      $val = $job;
      foreach ((array)$path as $k){
        if (is_array($val) && array_key_exists($k, $val)) { $val = $val[$k]; } else { $val = null; break; }
      }
      if (is_string($val) && $val !== '') return $this->pretty_contract($val);
    }
    return '';
  }

  private function fetch_contract_detail($slug, $id){
    $cache_key = 'mtl_ui_jobdetail_' . md5($slug . '|' . $id);
    $cached = get_transient($cache_key);
    if ($cached !== false) return $cached; // cache may be empty string

    $base = 'https://api.manatal.com/open/v3/career-page';
    $url  = sprintf('%s/%s/jobs/%s/', $base, urlencode($slug), urlencode($id));
    $res = wp_remote_get($url, ['timeout' => 20]);
    $contract = '';
    if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
      $j = json_decode(wp_remote_retrieve_body($res), true);
      if (is_array($j)) {
        $contract = $this->extract_contract($j);
      }
    }
    set_transient($cache_key, $contract, DAY_IN_SECONDS); // cache even if empty to avoid hammering
    return $contract;
  }

  public function shortcode_jobs($atts) {
    $atts = shortcode_atts(['slug' => '', 'per_page' => '200', 'view' => 'grid', 'cols' => '3', 'hover' => '1'], $atts);
    $core = self::DEP_CLASS;
    $slug = !empty($atts['slug']) ? $atts['slug'] : (property_exists($core, 'DEFAULT_SLUG') ? $core::DEFAULT_SLUG : 'alivioworks');
    $per_page = max(1, (int)$atts['per_page']);

    $base = property_exists($core, 'BASE') ? $core::BASE : 'https://api.manatal.com/open/v3/career-page';
    $url  = sprintf('%s/%s/jobs/?page=1&page_size=%d', $base, urlencode($slug), $per_page);

    $cache_key = 'mtl_ui_jobs_' . md5($url);
    $force = isset($_GET['mtl_refresh']) && current_user_can('manage_options');
    if (!$force) {
      $cached = get_transient($cache_key);
      if ($cached) $data = $cached;
    }
    if (empty($data)) {
      $res = wp_remote_get($url, ['timeout' => 20]);
      if (is_wp_error($res)) return '<p>Unable to load jobs right now.</p>';
      $code = wp_remote_retrieve_response_code($res);
      $body = wp_remote_retrieve_body($res);
      if ($code !== 200) return '<p>Unable to load jobs right now.</p>';
      $data = json_decode($body, true);
      if (!is_array($data)) return '<p>Unable to load jobs right now.</p>';
      set_transient($cache_key, $data, 300);
    }
    if (empty($data['results'])) return '<p>No jobs found.</p>';

    $items = [];
    foreach ($data['results'] as $job) {
      $title = !empty($job['position_name']) ? $job['position_name'] : (!empty($job['title']) ? $job['title'] : (!empty($job['name']) ? $job['name'] : 'View job'));
      $id    = !empty($job['id']) ? $job['id'] : (!empty($job['job_id']) ? $job['job_id'] : '');
      if (!$id) continue;
      $locs  = !empty($job['location_display']) ? $job['location_display'] : trim(implode(', ', array_filter([ $job['city'] ?? '', $job['state'] ?? '', $job['country'] ?? '' ])));
      $contract = $this->extract_contract($job);
      if ($contract === '') {
        // Fallback to detail endpoint once per job (cached 24h)
        $contract = $this->fetch_contract_detail($slug, $id);
      }
      $dateRaw = $job['opening_time'] ?? ($job['created_at'] ?? '');
      $link = home_url('/apply/?manatal_job=' . urlencode($id) . '&manatal_slug=' . urlencode($slug));
      $items[] = [
        'title' => $title, 'location' => $locs, 'contract' => $contract, 'date' => $dateRaw, 'url' => $link
      ];
    }
    $count = count($items);
    $uid = 'mtl-results-' . wp_generate_password(8, false, false);
    ob_start(); ?>
    <div class="mtl-toolbar" data-scope="#<?php echo esc_attr($uid); ?>">
      <div class="mtl-search">
        <input type="text" class="mtl-search-input" placeholder="Search by keyword, title, or location" />
        <button type="button" class="mtl-search-btn">Search</button>
        <div class="mtl-view-toggle" role="group" aria-label="View toggle">
          <button type="button" class="mtl-view-btn" data-view="grid" aria-pressed="<?php echo $atts['view']==='grid' ? 'true':'false'; ?>">Grid</button>
          <button type="button" class="mtl-view-btn" data-view="list" aria-pressed="<?php echo $atts['view']==='list' ? 'true':'false'; ?>">List</button>
        </div>
      </div>
      <div class="mtl-count" data-mtl-count><?php echo (int)$count; ?> job(s) found</div>
    </div>

    <div id="<?php echo esc_attr($uid); ?>"
         class="mtl-results mtl-cols-<?php echo (int)$atts['cols']; ?>"
         data-view="<?php echo esc_attr($atts['view']); ?>"
         data-hover="<?php echo esc_attr($atts['hover']); ?>"
         data-max-title="9999"
         data-title-style="font-size:1.15rem">
      <?php foreach ($items as $it): ?>
        <div class="mtl-item"
             data-title="<?php echo esc_attr($it['title']); ?>"
             data-location="<?php echo esc_attr($it['location']); ?>"
             data-contract="<?php echo esc_attr($it['contract']); ?>"
             data-date="<?php echo esc_attr($it['date']); ?>"
             data-url="<?php echo esc_url($it['url']); ?>"></div>
      <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
  }

  public function shortcode_featured_job($atts) {
    $atts = shortcode_atts(['slug' => '', 'per_page' => '200'], $atts);
    $core = self::DEP_CLASS;
    $slug = !empty($atts['slug']) ? $atts['slug'] : (property_exists($core, 'DEFAULT_SLUG') ? $core::DEFAULT_SLUG : 'alivioworks');

    $key_id = 'mtl_featureed_job_id_' . md5($slug);
    $key_checked = 'mtl_featureed_job_checked_' . md5($slug);
    $now = time();
    $last = (int) get_option($key_checked, 0);
    $featured_id = get_option($key_id, '');

    $base = property_exists($core, 'BASE') ? $core::BASE : 'https://api.manatal.com/open/v3/career-page';
    $url  = sprintf('%s/%s/jobs/?page=1&page_size=%d', $base, urlencode($slug), (int)$atts['per_page']);
    $res = wp_remote_get($url, ['timeout' => 20]);
    $ids = [];
    if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
      $j = json_decode(wp_remote_retrieve_body($res), true);
      if (!empty($j['results'])) {
        foreach ($j['results'] as $row) { $id = $row['id'] ?? ($row['job_id'] ?? ''); if ($id) $ids[$id] = $row; }
      }
    }

    if ($now - $last >= 86400 || empty($featured_id) || !isset($ids[$featured_id])) {
      if (!empty($ids)) {
        $keys = array_keys($ids);
        $featured_id = $keys[array_rand($keys)];
        update_option($key_id, $featured_id);
      }
      update_option($key_checked, $now);
    }

    if (!$featured_id) return '<p>No open jobs found.</p>';

    $job = isset($ids[$featured_id]) ? $ids[$featured_id] : null;
    if (!$job) return '<p>Featured job is no longer available.</p>';

    $title = !empty($job['position_name']) ? $job['position_name'] : (!empty($job['title']) ? $job['title'] : (!empty($job['name']) ? $job['name'] : 'View job'));
    $locs  = !empty($job['location_display']) ? $job['location_display'] : trim(implode(', ', array_filter([ $job['city'] ?? '', $job['state'] ?? '', $job['country'] ?? '' ])));
    $contract = $this->extract_contract($job);
    if ($contract === '') { $contract = $this->fetch_contract_detail($slug, $featured_id); }
    $dateRaw = $job['opening_time'] ?? ($job['created_at'] ?? '');
    $link = home_url('/apply/?manatal_job=' . urlencode($featured_id) . '&manatal_slug=' . urlencode($slug));

    ob_start(); ?>
    <section class="mtl-featured">
      <header><h3 class="mtl-featured__title"><a href="<?php echo esc_url($link); ?>"><?php echo esc_html($title); ?></a></h3></header>
      <ul class="mtl-featured__meta">
        <?php if (!empty($contract)): ?><li class="mtl-meta__row"><span class="mtl-icon">💼</span><?php echo esc_html($contract); ?></li><?php endif; ?>
        <?php if (!empty($locs)): ?><li class="mtl-meta__row"><span class="mtl-icon">📍</span><?php echo esc_html($locs); ?></li><?php endif; ?>
        <?php if (!empty($dateRaw)): ?><li class="mtl-meta__row"><span class="mtl-icon">📅</span><?php echo esc_html($dateRaw); ?></li><?php endif; ?>
      </ul>
      <p><a class="mtl-btn" href="<?php echo esc_url($link); ?>">View &amp; Apply</a></p>
    </section>
    <?php
    return ob_get_clean();
  }

  public function shortcode_jobs_search($atts) {
    $atts = shortcode_atts(['action' => '/jobs'], $atts);
    $action = esc_url(home_url($atts['action']));
    $q = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
    ob_start(); ?>
    <form class="mtl-search mtl-search--standalone" method="get" action="<?php echo $action; ?>">
      <input type="text" name="q" placeholder="Search by keyword, title, or location" value="<?php echo esc_attr($q); ?>" />
      <button type="submit">Search Jobs</button>
    </form>
    <?php
    return ob_get_clean();
  }
}

new Manatal_Careers_UI_Addon();
